<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps(['href' => '#', 'backhref' => '#']) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps(['href' => '#', 'backhref' => '#']); ?>
<?php foreach (array_filter((['href' => '#', 'backhref' => '#']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<div class="bg-white overflow-hidden shadow-sm sm:rounded-lg flex justify-between items-center p-3 my-3">
    <div class="text-gray-900 text-lg font-bold">
        <?php if($backhref != '#'): ?>
            <a href="<?php echo e($backhref); ?>" class="px-3 py-2 text-white bg-black rounded-full hover:bg-blue-900 me-4">
                <i class="fa-solid fa-arrow-left"></i>
            </a>
        <?php endif; ?>
        <?php echo e($slot); ?>

    </div>
    <?php if($href != '#'): ?>
        <a href="<?php echo e($href); ?>" class="px-4 py-2 text-white bg-blue-600 rounded hover:bg-blue-700">
            Add
        </a>
    <?php endif; ?>
</div>
<?php /**PATH C:\wamp64\www\meditation\resources\views/components/head-lable.blade.php ENDPATH**/ ?>