<x-app-layout>
    <x-head-lable>
        {{ __('WelCome') }}
    </x-head-lable>
</x-app-layout>
